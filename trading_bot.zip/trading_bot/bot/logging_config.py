"""
Structured logging configuration for the trading bot.
Logs to both console (INFO+) and a rotating file (DEBUG+).
"""

import logging
import logging.handlers
import os
from pathlib import Path


LOG_DIR = Path(__file__).parent.parent / "logs"
LOG_FILE = LOG_DIR / "trading_bot.log"


def setup_logging(level: str = "DEBUG") -> logging.Logger:
    """
    Configure root logger with:
      - StreamHandler  → INFO and above (human-readable, coloured)
      - RotatingFileHandler → DEBUG and above (structured, timestamped)

    Returns the 'trading_bot' logger.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    numeric_level = getattr(logging, level.upper(), logging.DEBUG)

    logger = logging.getLogger("trading_bot")
    if logger.handlers:          # prevent duplicate handlers on re-import
        return logger

    logger.setLevel(logging.DEBUG)

    # ── File handler ────────────────────────────────────────────────────────
    file_fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE,
        maxBytes=5 * 1024 * 1024,   # 5 MB
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(file_fmt)

    # ── Console handler ──────────────────────────────────────────────────────
    console_fmt = logging.Formatter(
        fmt="%(levelname)-8s %(message)s",
    )
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(console_fmt)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    logger.propagate = False

    return logger


def get_logger(name: str) -> logging.Logger:
    """Return a child logger under 'trading_bot'."""
    return logging.getLogger(f"trading_bot.{name}")
