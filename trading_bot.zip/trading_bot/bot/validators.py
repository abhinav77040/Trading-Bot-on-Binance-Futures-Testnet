"""
Input validation for trading bot CLI parameters.
All validators raise ValueError with human-readable messages on failure.
"""

from __future__ import annotations
from decimal import Decimal, InvalidOperation
from typing import Optional


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_LIMIT"}

# Futures symbols must be uppercase and end with a quote currency
QUOTE_CURRENCIES = ("USDT", "BUSD", "USD")


def validate_symbol(symbol: str) -> str:
    """Normalise and lightly validate a futures symbol (e.g. BTCUSDT)."""
    symbol = symbol.strip().upper()
    if len(symbol) < 5:
        raise ValueError(f"Symbol '{symbol}' looks too short. Example: BTCUSDT")
    if not any(symbol.endswith(q) for q in QUOTE_CURRENCIES):
        raise ValueError(
            f"Symbol '{symbol}' does not end with a recognised quote currency "
            f"({', '.join(QUOTE_CURRENCIES)}). Example: BTCUSDT"
        )
    if not symbol.isalnum():
        raise ValueError(f"Symbol '{symbol}' must be alphanumeric. Example: BTCUSDT")
    return symbol


def validate_side(side: str) -> str:
    """Validate BUY / SELL."""
    side = side.strip().upper()
    if side not in VALID_SIDES:
        raise ValueError(
            f"Invalid side '{side}'. Must be one of: {', '.join(sorted(VALID_SIDES))}"
        )
    return side


def validate_order_type(order_type: str) -> str:
    """Validate MARKET / LIMIT / STOP_LIMIT."""
    order_type = order_type.strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise ValueError(
            f"Invalid order type '{order_type}'. "
            f"Must be one of: {', '.join(sorted(VALID_ORDER_TYPES))}"
        )
    return order_type


def validate_quantity(quantity: str | float) -> Decimal:
    """Parse and validate quantity – must be a positive finite decimal."""
    try:
        qty = Decimal(str(quantity))
    except InvalidOperation:
        raise ValueError(f"Quantity '{quantity}' is not a valid number.")
    if qty <= 0:
        raise ValueError(f"Quantity must be greater than zero, got {qty}.")
    return qty


def validate_price(price: str | float | None) -> Optional[Decimal]:
    """Parse and validate price – must be positive if provided."""
    if price is None:
        return None
    try:
        p = Decimal(str(price))
    except InvalidOperation:
        raise ValueError(f"Price '{price}' is not a valid number.")
    if p <= 0:
        raise ValueError(f"Price must be greater than zero, got {p}.")
    return p


def validate_stop_price(stop_price: str | float | None) -> Optional[Decimal]:
    """Parse and validate stop price – used for STOP_LIMIT orders."""
    if stop_price is None:
        return None
    try:
        sp = Decimal(str(stop_price))
    except InvalidOperation:
        raise ValueError(f"Stop price '{stop_price}' is not a valid number.")
    if sp <= 0:
        raise ValueError(f"Stop price must be greater than zero, got {sp}.")
    return sp


def validate_order_params(
    symbol: str,
    side: str,
    order_type: str,
    quantity: str | float,
    price: str | float | None = None,
    stop_price: str | float | None = None,
) -> dict:
    """
    Run all field validations and return a dict of clean, typed values.
    Raises ValueError on the first validation failure encountered.
    """
    clean_symbol    = validate_symbol(symbol)
    clean_side      = validate_side(side)
    clean_type      = validate_order_type(order_type)
    clean_quantity  = validate_quantity(quantity)
    clean_price     = validate_price(price)
    clean_stop      = validate_stop_price(stop_price)

    # Semantic cross-field checks
    if clean_type == "LIMIT" and clean_price is None:
        raise ValueError("A LIMIT order requires a --price value.")

    if clean_type == "STOP_LIMIT":
        if clean_price is None:
            raise ValueError("A STOP_LIMIT order requires a --price (limit price) value.")
        if clean_stop is None:
            raise ValueError("A STOP_LIMIT order requires a --stop-price value.")

    if clean_type == "MARKET" and clean_price is not None:
        # warn-only: we'll log it but ignore the price server-side
        pass

    return {
        "symbol":     clean_symbol,
        "side":       clean_side,
        "order_type": clean_type,
        "quantity":   clean_quantity,
        "price":      clean_price,
        "stop_price": clean_stop,
    }
