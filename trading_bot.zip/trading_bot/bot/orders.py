"""
Order placement logic layer.

This module sits between the CLI and the raw BinanceFuturesClient.
It handles:
  - Pre-flight summary printing
  - Calling the client
  - Post-flight result formatting and display
  - Consistent error surfacing
"""

from __future__ import annotations

from decimal import Decimal
from typing import Optional

from .client import BinanceFuturesClient, BinanceAPIError, BinanceNetworkError
from .logging_config import get_logger

logger = get_logger("orders")


# ── Formatting helpers ────────────────────────────────────────────────────────

def _fmt(value: Optional[str], default: str = "N/A") -> str:
    """Return a display-friendly string for an optional field."""
    return value if value not in (None, "", "0", "0.00000000") else default


def _separator(char: str = "─", width: int = 60) -> str:
    return char * width


def print_order_request(
    symbol: str,
    side: str,
    order_type: str,
    quantity: Decimal,
    price: Optional[Decimal],
    stop_price: Optional[Decimal],
) -> None:
    """Pretty-print the order request summary to stdout."""
    print()
    print(_separator("═"))
    print("  ORDER REQUEST SUMMARY")
    print(_separator("═"))
    print(f"  Symbol     : {symbol}")
    print(f"  Side       : {side}")
    print(f"  Type       : {order_type}")
    print(f"  Quantity   : {quantity}")
    if price is not None:
        print(f"  Price      : {price}")
    if stop_price is not None:
        print(f"  Stop Price : {stop_price}")
    print(_separator())
    print()


def print_order_response(response: dict, success: bool = True) -> None:
    """Pretty-print the order response details to stdout."""
    if success:
        print(_separator("═"))
        print("  ORDER RESPONSE")
        print(_separator("═"))
        print(f"  Order ID     : {response.get('orderId', 'N/A')}")
        print(f"  Client OID   : {_fmt(response.get('clientOrderId'))}")
        print(f"  Symbol       : {response.get('symbol', 'N/A')}")
        print(f"  Side         : {response.get('side', 'N/A')}")
        print(f"  Type         : {response.get('type', 'N/A')}")
        print(f"  Status       : {response.get('status', 'N/A')}")
        print(f"  Orig Qty     : {_fmt(response.get('origQty'))}")
        print(f"  Executed Qty : {_fmt(response.get('executedQty'))}")
        print(f"  Avg Price    : {_fmt(response.get('avgPrice'))}")
        print(f"  Price        : {_fmt(response.get('price'))}")
        print(f"  Stop Price   : {_fmt(response.get('stopPrice'))}")
        print(f"  Time in Force: {_fmt(response.get('timeInForce'))}")
        print(f"  Update Time  : {response.get('updateTime', 'N/A')}")
        print(_separator())
        print()
        print("  ✓  Order placed successfully!")
    else:
        print()
        print("  ✗  Order failed. See log file for details.")
    print()


# ── Core order placement function ─────────────────────────────────────────────

def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: Decimal,
    price: Optional[Decimal] = None,
    stop_price: Optional[Decimal] = None,
    time_in_force: str = "GTC",
    verbose: bool = True,
) -> dict:
    """
    Place an order, print a request summary, and print the response.

    Parameters
    ----------
    client        : Authenticated BinanceFuturesClient
    symbol        : e.g. "BTCUSDT"
    side          : "BUY" | "SELL"
    order_type    : "MARKET" | "LIMIT" | "STOP_LIMIT"
    quantity      : base asset amount
    price         : required for LIMIT / STOP_LIMIT
    stop_price    : required for STOP_LIMIT
    time_in_force : "GTC" | "IOC" | "FOK"
    verbose       : whether to print summaries to stdout

    Returns
    -------
    The raw Binance order response dict.

    Raises
    ------
    BinanceAPIError     – API returned a business-logic error
    BinanceNetworkError – network-level failure
    ValueError          – bad input (should have been caught before this layer)
    """
    if verbose:
        print_order_request(symbol, side, order_type, quantity, price, stop_price)

    try:
        response = client.new_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
            stop_price=stop_price,
            time_in_force=time_in_force,
        )
    except BinanceAPIError as exc:
        logger.error("API error placing order: %s", exc)
        if verbose:
            print(f"\n  ✗  Binance API Error [{exc.code}]: {exc.msg}\n")
        raise
    except BinanceNetworkError as exc:
        logger.error("Network error placing order: %s", exc)
        if verbose:
            print(f"\n  ✗  Network Error: {exc}\n")
        raise
    except Exception as exc:
        logger.exception("Unexpected error placing order: %s", exc)
        if verbose:
            print(f"\n  ✗  Unexpected error: {exc}\n")
        raise

    if verbose:
        print_order_response(response, success=True)

    return response
