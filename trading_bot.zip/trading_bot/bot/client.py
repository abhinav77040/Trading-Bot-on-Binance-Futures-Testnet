"""
Binance Futures Testnet – low-level REST client.

Handles:
  - HMAC-SHA256 request signing
  - Timestamp + recvWindow management
  - HTTP retries with exponential back-off
  - Full request/response logging
  - Structured error propagation
"""

from __future__ import annotations

import hashlib
import hmac
import time
from decimal import Decimal
from typing import Any, Optional
from urllib.parse import urlencode

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .logging_config import get_logger

logger = get_logger("client")

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
DEFAULT_RECV_WINDOW = 5_000   # milliseconds


class BinanceAPIError(Exception):
    """Raised when the Binance API returns a non-2xx response or error code."""

    def __init__(self, status_code: int, code: int, msg: str):
        self.status_code = status_code
        self.code = code
        self.msg = msg
        super().__init__(f"Binance API error {code}: {msg} (HTTP {status_code})")


class BinanceNetworkError(Exception):
    """Raised when a network-level failure occurs (timeout, connection error …)."""


class BinanceFuturesClient:
    """
    Thin wrapper around the Binance Futures USDT-M REST API (testnet).

    Usage
    -----
    client = BinanceFuturesClient(api_key="…", api_secret="…")
    resp = client.new_order(symbol="BTCUSDT", side="BUY",
                            order_type="MARKET", quantity=Decimal("0.001"))
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = TESTNET_BASE_URL,
        recv_window: int = DEFAULT_RECV_WINDOW,
        timeout: int = 10,
    ):
        if not api_key or not api_secret:
            raise ValueError("api_key and api_secret must both be non-empty strings.")

        self._api_key    = api_key
        self._api_secret = api_secret.encode()
        self._base_url   = base_url.rstrip("/")
        self._recv_window = recv_window
        self._timeout    = timeout
        self._session    = self._build_session()

        logger.info("BinanceFuturesClient initialised (base_url=%s)", self._base_url)

    # ── Session / retry setup ────────────────────────────────────────────────

    @staticmethod
    def _build_session() -> requests.Session:
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "DELETE"],
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://",  adapter)
        return session

    # ── Signing helpers ──────────────────────────────────────────────────────

    def _timestamp(self) -> int:
        return int(time.time() * 1000)

    def _sign(self, params: dict) -> str:
        query = urlencode(params)
        return hmac.new(self._api_secret, query.encode(), hashlib.sha256).hexdigest()

    def _signed_params(self, extra: dict) -> dict:
        params = {
            "timestamp":  self._timestamp(),
            "recvWindow": self._recv_window,
            **extra,
        }
        params["signature"] = self._sign(params)
        return params

    # ── HTTP helpers ─────────────────────────────────────────────────────────

    def _headers(self) -> dict:
        return {"X-MBX-APIKEY": self._api_key}

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict] = None,
        signed: bool = False,
    ) -> Any:
        url = f"{self._base_url}{path}"
        params = params or {}

        if signed:
            params = self._signed_params(params)

        # Sanitise for logging (hide full signature)
        safe = {k: ("…" if k == "signature" else v) for k, v in params.items()}
        logger.debug("→ %s %s  params=%s", method.upper(), path, safe)

        try:
            if method.upper() in ("GET", "DELETE"):
                response = self._session.request(
                    method, url,
                    params=params,
                    headers=self._headers(),
                    timeout=self._timeout,
                )
            else:
                response = self._session.request(
                    method, url,
                    data=params,
                    headers=self._headers(),
                    timeout=self._timeout,
                )
        except requests.exceptions.Timeout as exc:
            logger.error("Network timeout: %s", exc)
            raise BinanceNetworkError(f"Request timed out: {exc}") from exc
        except requests.exceptions.ConnectionError as exc:
            logger.error("Network connection error: %s", exc)
            raise BinanceNetworkError(f"Connection error: {exc}") from exc
        except requests.exceptions.RequestException as exc:
            logger.error("Unexpected requests error: %s", exc)
            raise BinanceNetworkError(f"Request failed: {exc}") from exc

        logger.debug("← HTTP %s  body=%s", response.status_code, response.text[:500])

        try:
            data = response.json()
        except ValueError:
            logger.error("Non-JSON response: %s", response.text[:300])
            response.raise_for_status()
            raise

        if isinstance(data, dict) and "code" in data and data["code"] != 200:
            logger.error(
                "Binance error code=%s msg='%s'", data.get("code"), data.get("msg")
            )
            raise BinanceAPIError(
                status_code=response.status_code,
                code=int(data["code"]),
                msg=str(data.get("msg", "Unknown error")),
            )

        if not response.ok:
            logger.error("HTTP error %s: %s", response.status_code, response.text[:300])
            response.raise_for_status()

        return data

    # ── Public API methods ────────────────────────────────────────────────────

    def get_exchange_info(self) -> dict:
        """Fetch exchange info (includes symbol filters / precision)."""
        return self._request("GET", "/fapi/v1/exchangeInfo")

    def get_account(self) -> dict:
        """Fetch futures account details (balance, positions …)."""
        return self._request("GET", "/fapi/v2/account", signed=True)

    def new_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: Decimal,
        price: Optional[Decimal] = None,
        stop_price: Optional[Decimal] = None,
        time_in_force: str = "GTC",
    ) -> dict:
        """
        Place a new order on Binance Futures (USDT-M) testnet.

        Parameters
        ----------
        symbol        : e.g. "BTCUSDT"
        side          : "BUY" | "SELL"
        order_type    : "MARKET" | "LIMIT" | "STOP" (stop-limit)
        quantity      : base asset amount
        price         : required for LIMIT / STOP orders
        stop_price    : required for STOP orders
        time_in_force : "GTC" | "IOC" | "FOK" (ignored for MARKET)

        Returns
        -------
        Full order response dict from Binance.
        """
        params: dict = {
            "symbol":   symbol,
            "side":     side,
            "type":     "STOP" if order_type == "STOP_LIMIT" else order_type,
            "quantity": str(quantity),
        }

        if order_type in ("LIMIT", "STOP_LIMIT"):
            params["price"]       = str(price)
            params["timeInForce"] = time_in_force

        if order_type == "STOP_LIMIT":
            params["stopPrice"] = str(stop_price)

        logger.info(
            "Placing %s %s order | symbol=%s qty=%s price=%s stopPrice=%s",
            side, order_type, symbol, quantity, price, stop_price,
        )

        result = self._request("POST", "/fapi/v1/order", params=params, signed=True)
        logger.info("Order placed successfully | orderId=%s status=%s",
                    result.get("orderId"), result.get("status"))
        return result

    def cancel_order(self, symbol: str, order_id: int) -> dict:
        """Cancel an open order by orderId."""
        params = {"symbol": symbol, "orderId": order_id}
        logger.info("Cancelling order | symbol=%s orderId=%s", symbol, order_id)
        return self._request("DELETE", "/fapi/v1/order", params=params, signed=True)

    def get_order(self, symbol: str, order_id: int) -> dict:
        """Query a single order by orderId."""
        params = {"symbol": symbol, "orderId": order_id}
        return self._request("GET", "/fapi/v1/order", params=params, signed=True)
